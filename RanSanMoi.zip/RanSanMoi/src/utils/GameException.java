package utils;

public class GameException extends Exception {
    public GameException(String message) {
        super(message);
    }
}